ANTHONY NEOPHYTOU
ST10090375
PROGRAMMING PART 2
READ ME

--------------------------------------------Part 1----------------------------------------------------------

1. Open Visual Studo and run the application.
2. A window will open with 4 buttons.
3. Select Replacing Books as Identifying Areas and Finding Call Numbers are disable.
4. Game can be selected if the user wants to use the gamification feature.
5. A new window will open up when replacing books has been selected.
6. The user must press generate numbers so 10 call numbers can be generated and displayed in the box.
7. The user can select a number and press the up or down button to try sort the numbers.
8. The user can then press sort and the system will fix any mistakes if it hasnt been sorted correctly
9. The game can be selected again and a pop up window of Tic Tac Toe will open.

---------------------------------------------Part 2---------------------------------------------------------
10. The user can select Identifying areas on the main window when the have finished with Replacing Books.
11. The page will open and the user can read instructions and then begin match the columns.
12. The user can select an item in Column A and an item in Column B and then press add and it will be placed into Match Column.
13. The user can then press on the item in match and it will say if it is correct or not and then the process can be repeated until Column A has no items.
14. When the last item is added from Column A, the application will say it is complete.
15. Items that are checked and are correct will add points to the progress bar so it can fill up.
16. The user can also press shuffle which will switch the call numbers and the descriptions.
17. The match the columns can be reset as many times to continue learning and it will randomly generate all the items.

------------------------------------------Part 3-----------------------------------------------------------
18. The user can now select finding call numbers when they have finisahed with identifying Areas.
19. The page will open and the user will be presented with a button stating start quiz which they must press.
20. The user will then see a question pop up and with a description and then numbers and descriptions will appear in the box.
21. The user will need to see the question and press the number and description they think matches to that question.
22. if the answer is correct it wqill say its correct and the next level of question will be displayed related to that original question.
23. if it is incorrect a message will say its incorrect and will load an entirely new question.
24. When answers are correct they will fill up the progress bar until it is full.
25. The quiz can be take many times as there are lots of numbers in the dewey system to choose from. 
26. When the user is done with this or wants to change they can make their way around the app again depending on what they want to do.